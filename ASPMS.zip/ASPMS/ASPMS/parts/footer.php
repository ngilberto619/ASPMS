<footer class="mainfooter">
<div id="grpmembers">
<p>Copyright &copy; 20015|all Right is for Gilbert<br>
designed by NGENDAHAYO Gilbert 11AK01746<br>
 <br>Contact us on 0783218734</p>
</div>
<div class="socials">
<h3>Share on Social network: </h3>
<a href="http://WWW.facebook.com"><img src="images/facebook.png"/></a>
<a href="http://WWW.twitter.com"><img src="images/twitter.png"/></a>
</div>

    </footer>
</div>
</body>