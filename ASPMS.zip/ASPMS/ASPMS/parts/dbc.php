<?php
$link = mysql_connect("127.0.0.1","root","") or die("Couldn't make connection.");
$db = mysql_select_db("parts") or die("Couldn't select database");

?>